#!/bin/bash

mostrar_ayuda() {
    echo "Uso: $0 [opciones] origen destino"
    echo "Opciones:"
    echo "  -h    Muestra esta ayuda"
    exit 0
}

if [[ $1 == "-h" ]]; then
    mostrar_ayuda
fi

if [ "$#" -ne 2 ]; then
    echo "Error: Se requieren exactamente dos argumentos."
    mostrar_ayuda
fi

origen="$1"
destino="$2"

if [[ ! -d "$origen" ]]; then
    echo "Error: El sistema de archivos de origen '$origen' no existe."
    exit 1
fi

if ! mountpoint -q "$destino"; then
    echo "Error: El sistema de archivos de destino '$destino' no está montado."
    exit 1
fi

fecha=$(date +"%Y%m%d")

nombre_backup="$(basename "$origen")_bkp_$fecha.tar.gz"
ruta_backup="$destino/$nombre_backup"

tar -czf "$ruta_backup" -C "$(dirname "$origen")" "$(basename "$origen")"
if [ $? -eq 0 ]; then
    echo "Backup creado exitosamente en '$ruta_backup'"
else
    echo "Error: Falló la creación del backup."
    exit 1
fi
