#!/bin/bash

for dir in /root /etc /opt /var /www_dir /backup_dir; do
    tar -czvf "${dir##*/}_bkp.tar.gz" "$dir"
done